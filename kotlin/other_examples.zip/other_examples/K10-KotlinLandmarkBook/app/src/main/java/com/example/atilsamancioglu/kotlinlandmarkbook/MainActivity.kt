package com.example.atilsamancioglu.kotlinlandmarkbook

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.media.MediaMetadataCompat
import android.widget.AdapterView
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val landmarkNames : ArrayList<String> = loadLanmarksNames()
        val landmarkImages : ArrayList<Bitmap> = loadLanmarksImages()

        val arrayAdapter = ArrayAdapter(this,android.R.layout.simple_list_item_1,landmarkNames)

        listView.adapter = arrayAdapter
        
        listView.onItemClickListener = AdapterView.OnItemClickListener { adapterView, view, i, l ->

            val intent = Intent(applicationContext,DetailActivity::class.java)
            intent.putExtra("name",landmarkNames[i])

            val bitmap = landmarkImages[i]

//            val chosen = Globals.Chosen
            Globals.chosenImage = bitmap

            startActivity(intent)


        }

    }

    private fun loadLanmarksNames(): ArrayList<String> {

        var landmarkNames = ArrayList<String>()

        landmarkNames.add("Pisa")
        landmarkNames.add("Colosseum")
        landmarkNames.add("Eiffel")
        landmarkNames.add("London Bridge")

        return landmarkNames
    }

    private fun loadLanmarksImages(): ArrayList<Bitmap> {

        var images = ArrayList<Bitmap>()

        val pisa = BitmapFactory.decodeResource(applicationContext.resources,R.drawable.pisa)
        val colosseum = BitmapFactory.decodeResource(applicationContext.resources,R.drawable.colosseum)
        val eiffel = BitmapFactory.decodeResource(applicationContext.resources, R.drawable.eiffel)
        val londonBridge = BitmapFactory.decodeResource(applicationContext.resources,R.drawable.londonbridge)

        images.add(pisa)
        images.add(colosseum)
        images.add(eiffel)
        images.add(londonBridge)

        return images
    }
}
