package com.mobapptuts.kotlinfragments

import com.bumptech.glide.annotation.GlideModule
import com.bumptech.glide.module.AppGlideModule

/**
 * Created by nigelhenshaw on 2018/01/23.
 */
@GlideModule
class MyAppGlideModule : AppGlideModule()
