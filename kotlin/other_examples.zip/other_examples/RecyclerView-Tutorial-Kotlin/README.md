# RecyclerView-Tutorial-Kotlin
This is the full source code from the following article on using RecyclerView in Android

https://medium.com/eijaz/using-recyclerview-in-android-kotlin-722991e86bf3
